import styles from './App.module.css';
import { createSignal, createContext, useContext } from 'solid-js';
import MetaMaskOnboarding from '@metamask/onboarding';
import GUN from 'gun';

const [getAccount, setAccount] = createSignal();
const [getProfile, setProfile] = createSignal();
const [getPreviewImg, setPreviewImg] = createSignal();
const [getUserUploads, setUserUploads] = createSignal();

const onboarding = new MetaMaskOnboarding();

const onClickConnect = async () => {
  try {
    const activeAcc = await ethereum.request({
      method: 'eth_requestAccounts',
    });
    setAccount(activeAcc[0]);
    loadProfile();

  } catch (error) {
    console.error(error);

  }
};

function loginMetaMask() {
  console.log("Login clicked");

  if (!MetaMaskOnboarding.isMetaMaskInstalled) {
    console.log("MetaMask not installed.");
    onboarding.startOnboarding();
    return;
  }

  if (getAccount()) {
    console.log("Already logged in.");
    if (onboarding) {
      onboarding.stopOnboarding();
    }

    
  } else {
    onClickConnect();
  }
};


import { Web3Storage } from 'web3.storage'

//Initialize web3storage with api token obtained with a web3.storage account.
const client = new Web3Storage({token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweERkQWNGNTNjZjIyMUY3OTFGOUNGMjI3NUUzZDc0MmVCNWFDOUVjYUUiLCJpc3MiOiJ3ZWIzLXN0b3JhZ2UiLCJpYXQiOjE2NjA5MDE2MjU3NzMsIm5hbWUiOiJUZXN0In0.L_YT4xyS6k0PcLryTxLMBrIjImXc_H4ch1a0uR3gWi8"})

function refreshUploads() {
  var userUploads = [];

  appDb.get(getAccount()).get("uploads").map((data, id) => {
    userUploads.push(data);
  });

  setUserUploads(userUploads);
}

function uploadClick() {
  const fileInput = document.querySelector('input[type="file"]');

  if (fileInput.files[0]) {

    //Upload file to web3.storage
    client.put(fileInput.files)
      .then((rootCid) => {
        //Upload successfull, retrieved rootCid;
        console.log("Upload returns cid:" + rootCid);
        appDb.get(getAccount()).get("uploads").set(rootCid);

        refreshUploads();
      })

  } else {
    console.log("empty file input")
  }
}

function loadUploadImg() {
  //loads files using web3.storage using CID provided after upload;

  //let cid = "bafkreigmjum7tm5hxtiuq6jixgt5rq7sf7y3v5tkdkvjgagobwxwpmceyq"; 
  //https://bafybeib4ku57c5jfpv25cwkrm4meh5jgl5dg5fy5zfkfii4zyqauutghpi.ipfs.w3s.link/awkwardsmilecat.png
  //https://bafybeigu44ywswzqfeh7f4ejbgmfefnir4okvxrxz7pjt7svsrfuaun4jm.ipfs.w3s.link/yellCat.png

  /*
  setPreviewImg(`https://cloudflare-ipfs.com/ipfs/${cid}`);

  client.list().then((upload)=> {
    console.log(`storage: ${upload.cid}  ${upload.name}`)
  })*/

  if (getUserUploads() == null) {
    console.log("uploads has not loaded");
    refreshUploads();
    
  }

  //Get latest upload
  let length = getUserUploads().length;
  let latestUploadCid = getUserUploads()[length-1];
  console.log("latest upload cid: " + latestUploadCid);

  //List all uploaded content;
  getUserUploads().forEach((cid) => {
    console.log("UserUpload: " + cid);
  })

  client.get(latestUploadCid)
    .then((res)=> { //get request successful, returns http response;
      //retrieve file;
      res.files()
        .then((files)=> {
          //get file sucessful;
          for (const file of files) {
            console.log(`Loaded item ${file.cid} ${file.name} ${file.size}`)
            
            setPreviewImg(`https://${latestUploadCid}.ipfs.w3s.link/${file.name}`)
            break;
          }
        })
        .catch((err)=> {
          console.log("res.files() failed " + err);
        })
    })
    .catch((err)=> {
      console.log("res get rejected " + err)
    })
}


//decen db GUNjs
export const appDb = GUN();
const [getDisplayName, setDisplayName] = createSignal();
const [getTargetkey, setTargetkey] = createSignal();

function updateName(){
  console.log("update name " + getDisplayName() + " for " + getAccount());
  
  if (getAccount()) {
    appDb.get(getAccount()).put({
      displayName: getDisplayName()
    })
  }
}

//Load profile data such as Display Name;
function loadProfile() {
  appDb.get(getAccount()).once((data, key) => {
    if (data) {
      //User data successfully loaded
      console.log("Load profile key: " + key + " Data:" + JSON.stringify(data));
      setDisplayName(data.displayName);
      setProfile(data);
    }
  })
}

//Friend system
const [getFriendsList, setFriendsList] = createSignal();

function updateFriendsList() {
  var friendsList = [];

  appDb.get(getAccount()).get("friends").map((data, id) => {
    if (data != null) {
      friendsList.push(data);
    }
  });
  setFriendsList(friendsList);
}

function addFriend() {
  console.log("add friend " + getTargetkey());

  if (getAccount()) {
    appDb.get(getTargetkey()).once((data, key) => {
      if (data) {
        //load existing user profile
        let displayName = data.displayName;
        console.log("Adding " + displayName + " as friend");

        appDb.get(getAccount()).get("friends").get(getTargetkey()).put(displayName);

        updateFriendsList();
      } else {
        console.log("Target user does not exist: " + getTargetkey());
        
      }
    })

  }
}

function removeFriend(name) {
  console.log("removing friend " + name);

  if (getAccount()) {
    appDb.get(getAccount()).get("friends").map((data, id) => {
      if (data == name) {
        console.log("removed user: " + name);
        appDb.get(getAccount()).get("friends").get(id).put(null);
      }
    });
  }

  updateFriendsList();
}

function renderFriendsList() {
  if (getFriendsList() == null) {
    return "no friends"
  }

  console.log("render friends list : " + getFriendsList());

  return (
    <div>
      {getFriendsList().map((data) => <li>{data} <a href="#" onClick={ () => { removeFriend(data) } }>remove</a></li>)}
    </div>
  );
}

function App() {
  if (MetaMaskOnboarding.isMetaMaskInstalled) {
    ethereum.on('accountsChanged', (activeAcc) => {
      setAccount(activeAcc[0]);
      loadProfile();
      updateFriendsList();

    });

    ethereum.request({
      method: 'eth_accounts',
    }).then((activeAcc) => {
      setAccount(activeAcc[0]);
      loadProfile();
      updateFriendsList();

    });
  }

  return (
    <div class={styles.App}>
      <header class={styles.header}>
        <h3>Prototype: Privacy Dragons</h3>
        <h2>{ getAccount() ? ("You are logged in as: " + getDisplayName() + "\n(" + getAccount() + ")") : "Login with meta mask"}</h2>
        <button onClick={loginMetaMask}>{getAccount() ? "Log out" : "Log in"}</button>
        <br/>
        
        <input type="text" onChange={(e) => {
          let name = e.target.value;
          setDisplayName(name);
        }}></input>
        <button onClick={updateName}>Set profile name</button>
        <br/>
        
        
        <button onClick={uploadClick}><input type='file' accept='image/png, image/gif, image/jpeg'/>Upload</button>
        <br/>

        <button onClick={loadUploadImg}>Load Image from IPFS</button>
        <br/>
        <img src={getPreviewImg()} style="margin-bottom: 30px"></img>

        <input type="text" onChange={(e) => {
          let targetKey = e.target.value;
          setTargetkey(targetKey);
        }}></input>
        <button onClick={addFriend}>Add Friend</button>
        <button onClick={updateFriendsList}>Refresh Friends</button>
        <br/>

        <div>{renderFriendsList()}</div>
      </header>
    </div>
  );
}

export default App;
